import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngo-layout',
  templateUrl: './ngo-layout.component.html',
  styleUrls: ['./ngo-layout.component.scss']
})
export class NgoLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
