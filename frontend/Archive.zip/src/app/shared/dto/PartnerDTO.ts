export class PartnerDTO {
  public id: number;
  public name: string;
  public description: string;
  public logo: any;
  public phone: string;
  public mail: string;
  public representative: string;
  public address:string;
}
