import {ProjectDTO} from './ProjectDTO';

export class ProjectPositionDTO {
  public id: number;
  public name: string;
  public description: string;
  public project: ProjectDTO;
}
