
export class UserDTOImage {
  public profilePicture: any;
}
