import {UserDTO} from './UserDTO';
import {NgoDTO} from './NgoDTO';

export class FunctionDTO{
  public id: number;
  public name: string;
  public description: string;
}
