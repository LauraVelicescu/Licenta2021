export class PasswordDTO{
  public oldPassword: string;
  public token: string;
  public newPassword: string;
}
