export enum ProjectBudgetIncreaseRequestStatus {
  NEW,
  UNDER_REVIEW,
  ACCEPTED,
  REJECTED
}
