package ro.fii.licenta.api.dao;

public enum PersonType {
    NORMAL, ADMIN
}