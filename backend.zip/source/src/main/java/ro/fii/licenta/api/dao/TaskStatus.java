package ro.fii.licenta.api.dao;

public enum TaskStatus {
 TO_DO, IN_PROGRESS, BLOCKED, DONE, OUT_OF_SCOPE 
}
