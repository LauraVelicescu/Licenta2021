package ro.fii.licenta.api.dao;

public enum ProjectExpenseType {

	REQUESTED,
	TASK,
	ORGANIZATIONAL,
	OTHER
}
